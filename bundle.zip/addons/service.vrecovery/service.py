import xbmc, json, xbmcgui, requests, os

monitor = xbmc.Monitor()
progress = xbmcgui.DialogProgress()

def main():
	xbmc.executebuiltin("ActivateWindow(10000)")
	monitor.waitForAbort(2)
	a = xbmc.translatePath("special://profile/addon_data/service.vavoo/settings.xml").decode("utf-8")
	if os.path.exists(a):
		os.remove(a)
	try:
		with open("/sdcard/data.json", "r") as m:
			veclist = json.load(m)
	except:
		veclist=[]
	
	progress.create("Vec Builder", "STARTE")
	i=0
	while not monitor.abortRequested() and not progress.iscanceled():
		i+=1
		systemInfos ={
			"reason": "check/missing",
			"apk_package": "unknown",
			"service_version": "1.2.26",
			"meta_system": "Windows",
			"platform": "win32",
			"version": "2.2",
			"branch": "addonv22",
			"meta_platform": "Windows-7-6.1.7601-SP1', 'recovery_version': '1.1.7",
			"meta_version": "6.1.7601",
			"recovery_version": "1.1.7",
			"processor": "Intel64 Family 6 Model 42 Stepping 7, GenuineIntel"}
		#systemInfos["reason"] = " check/missing"
		#systemInfos["token"] = requests.post("https://www.vavoo.tv/api/box/guest", json=systemInfos).json()["response"]["token"]
		#systemInfos["reason"] = " check"
		veclist.append(xbmc.preparevavoorequest(json.dumps(systemInfos)))
		progress.update(i, "Laenge Veclist: %s\nNeu erstellt: %s" % (len(veclist), i))
	with open("/sdcard/data.json", "w") as m:
		json.dump(veclist, m, indent=4)
	monitor.waitForAbort(2)
	os._exit(1)

if __name__ == '__main__':
	main()