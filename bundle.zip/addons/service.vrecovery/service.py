import xbmc, json, xbmcgui, requests, os

monitor = xbmc.Monitor()
progress = xbmcgui.DialogProgress()

def main():
	xbmc.executebuiltin("ActivateWindow(10000)")
	monitor.waitForAbort(2)
	a = xbmc.translatePath("special://profile/addon_data/service.vavoo/settings.xml").decode("utf-8")
	if os.path.exists(a):
		os.remove(a)
	try:
		with open("/sdcard/github-repo/michaz1988.github.io/data.json", "r") as m:
			veclist = json.load(m)
	except:
		veclist=[]
	
	progress.create("Vec Builder", "STARTE")
	i=0
	while not monitor.abortRequested() and not progress.iscanceled():
		i+=1
		systemInfos ={
			"ro.product.manufacturer": "Amlogic",
			"ro.build.product": "p212_9377",
			"apk_id": "default",
			"apk_package": "tv.vavoo.app",
			"ro.build.version.release": "6.0.3",
			"android_package_name": "tv.vavoo.app",
			"service_version": "1.2.26",
			"apk_sha1": "b76ca38e05d72f2b736af60a42fcbee2dfb8f061",
			"meta_system": "Linux",
			"apk_file": "MEDIA.RSA",
			"platform": "vavoo",
			"version": "2.6",
			"branch": "master",
			"android_installer": "com.android.vending",
			"meta_version": "#1 SMP PREEMPT Tue Mar 7 16:20:38 UTC 2023",
			"recovery_version": "1.1.13",
			"processor": "arm"}
		systemInfos["reason"] = " check/missing"
		#systemInfos["token"] = requests.post("https://www.vavoo.tv/api/box/guest", json=systemInfos).json()["response"]["token"]
		#systemInfos["reason"] = " check"
		veclist.append(xbmc.preparevavoorequest(json.dumps(systemInfos)))
		progress.update(i, "Laenge Veclist: %s\nNeu erstellt: %s" % (len(veclist), i))
	with open("/sdcard/github-repo/michaz1988.github.io/data.json", "w") as m:
		json.dump(veclist, m, indent=4)
	monitor.waitForAbort(2)
	os._exit(1)

if __name__ == '__main__':
	main()